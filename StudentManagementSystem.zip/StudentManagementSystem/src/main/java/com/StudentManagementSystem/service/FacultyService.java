package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.model.Faculty;
import com.StudentManagementSystem.repository.FacultyRepository;

@Service
public class FacultyService {

    @Autowired
    private FacultyRepository repo;

    public Faculty addFaculty(Faculty faculty) {
        return repo.save(faculty);
    }

    public List<Faculty> getAllFaculty() {
        return repo.findAll();
    }

    public Faculty getFaculty(String facultyId) {
        return repo.findByFacultyId(facultyId);
    }

    public String deleteFaculty(String facultyId) {

        Faculty faculty = repo.findByFacultyId(facultyId);

        repo.delete(faculty);

        return "Faculty Deleted Successfully";
    }
    
    public long countFaculty() {
        return repo.count();
    }
}