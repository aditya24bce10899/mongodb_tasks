package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.model.Course;
import com.StudentManagementSystem.repository.CourseRepository;

@Service
public class CourseService {

    @Autowired
    private CourseRepository repo;

    public Course addCourse(Course course) {
        return repo.save(course);
    }

    public List<Course> getAllCourses() {
        return repo.findAll();
    }

    public Course getCourse(String courseId) {
        return repo.findByCourseId(courseId);
    }

    public String deleteCourse(String courseId) {

        Course course = repo.findByCourseId(courseId);

        repo.delete(course);

        return "Course Deleted Successfully";
    }
    public long countCourses() {
        return repo.count();
    }
}