package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.model.Attendance;
import com.StudentManagementSystem.repository.AttendanceRepository;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRepository repo;

    public Attendance addAttendance(Attendance attendance) {
        return repo.save(attendance);
    }

    public List<Attendance> getAllAttendance() {
        return repo.findAll();
    }

    public Attendance getAttendance(String attendanceId) {
        return repo.findByAttendanceId(attendanceId);
    }

    public List<Attendance> getStudentAttendance(String studentId) {
        return repo.findByStudentId(studentId);
    }

    public String deleteAttendance(String attendanceId) {

        Attendance attendance =
                repo.findByAttendanceId(attendanceId);

        if(attendance != null) {
            repo.delete(attendance);
            return "Attendance Deleted Successfully";
        }

        return "Attendance Not Found";
    }
}