package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.model.Student;
import com.StudentManagementSystem.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository repo;

    // CREATE
    public Student addStudent(Student student) {
        return repo.save(student);
    }
    
    public List<Student> addStudents(List<Student> students) {
        return repo.saveAll(students);
    }

    // READ ALL
    public List<Student> getAllStudents() {
        return repo.findAll();
    }

    // READ ONE
    public Student getStudent(String studentId) {
        return repo.findByStudentId(studentId);
    }

    // UPDATE
    public Student updateStudent(String studentId, Student updatedStudent) {

        Student student = repo.findByStudentId(studentId);

        student.setName(updatedStudent.getName());
        student.setEmail(updatedStudent.getEmail());
        student.setCourse(updatedStudent.getCourse());
        student.setSemester(updatedStudent.getSemester());
        student.setMarks(updatedStudent.getMarks());

        return repo.save(student);
    }

    // DELETE
    public String deleteStudent(String studentId) {

        Student student = repo.findByStudentId(studentId);

        repo.delete(student);

        return "Student Deleted Successfully";
    }
    
    public Student getTopper() {

        return repo.findAll()
                .stream()
                .max((s1, s2) ->
                        Double.compare(
                                s1.getMarks(),
                                s2.getMarks()))
                .orElse(null);
    }
    // COUNT
    public long countStudents() {
        return repo.count();
    }
}