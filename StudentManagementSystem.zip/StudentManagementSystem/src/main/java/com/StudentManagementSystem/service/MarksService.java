package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.model.Marks;
import com.StudentManagementSystem.repository.MarksRepository;

@Service
public class MarksService {

    @Autowired
    private MarksRepository repo;

    public Marks addMarks(Marks marks) {

        marks.setTotalMarks(
                marks.getInternalMarks()
                + marks.getExternalMarks());

        return repo.save(marks);
    }

    public List<Marks> getAllMarks() {
        return repo.findAll();
    }

    public Marks getMarks(String markId) {
        return repo.findByMarkId(markId);
    }

    public List<Marks> getStudentMarks(String studentId) {
        return repo.findByStudentId(studentId);
    }

    public String deleteMarks(String markId) {

        Marks marks = repo.findByMarkId(markId);

        repo.delete(marks);

        return "Marks Deleted Successfully";
    }
    
    public long countMarks() {
        return repo.count();
    }
}