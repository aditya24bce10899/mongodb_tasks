package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.model.Enrollment;
import com.StudentManagementSystem.repository.EnrollmentRepository;

@Service
public class EnrollmentService {

    @Autowired
    private EnrollmentRepository repo;

    public Enrollment addEnrollment(Enrollment enrollment) {
        return repo.save(enrollment);
    }

    public List<Enrollment> getAllEnrollments() {
        return repo.findAll();
    }

    public Enrollment getEnrollment(String enrollmentId) {
        return repo.findByEnrollmentId(enrollmentId);
    }

    public List<Enrollment> getStudentEnrollments(String studentId) {
        return repo.findByStudentId(studentId);
    }

    public List<Enrollment> getCourseEnrollments(String courseId) {
        return repo.findByCourseId(courseId);
    }

    public String deleteEnrollment(String enrollmentId) {

        Enrollment enrollment =
                repo.findByEnrollmentId(enrollmentId);

        repo.delete(enrollment);

        return "Enrollment Deleted Successfully";
    }
    
    public long countEnrollments() {
        return repo.count();
    }
}