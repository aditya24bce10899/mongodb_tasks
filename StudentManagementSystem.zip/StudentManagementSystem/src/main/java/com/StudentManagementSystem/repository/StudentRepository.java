package com.StudentManagementSystem.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.StudentManagementSystem.model.Student;

public interface StudentRepository extends MongoRepository<Student, String> {

    Student findByStudentId(String studentId);

}