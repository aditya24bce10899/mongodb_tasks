package com.StudentManagementSystem.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.StudentManagementSystem.model.Admin;

public interface AdminRepository extends MongoRepository<Admin, String> {

    Admin findByUsername(String username);
}