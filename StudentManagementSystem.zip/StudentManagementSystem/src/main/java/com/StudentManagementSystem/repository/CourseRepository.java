package com.StudentManagementSystem.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.StudentManagementSystem.model.Course;

public interface CourseRepository extends MongoRepository<Course, String> {

    Course findByCourseId(String courseId);
}