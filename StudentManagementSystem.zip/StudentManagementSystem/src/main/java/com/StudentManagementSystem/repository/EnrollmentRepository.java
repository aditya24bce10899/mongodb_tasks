package com.StudentManagementSystem.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.StudentManagementSystem.model.Enrollment;

public interface EnrollmentRepository extends MongoRepository<Enrollment, String> {

    Enrollment findByEnrollmentId(String enrollmentId);

    List<Enrollment> findByStudentId(String studentId);

    List<Enrollment> findByCourseId(String courseId);
}