package com.StudentManagementSystem.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.StudentManagementSystem.model.Marks;

public interface MarksRepository extends MongoRepository<Marks, String> {

    Marks findByMarkId(String markId);

    List<Marks> findByStudentId(String studentId);
}