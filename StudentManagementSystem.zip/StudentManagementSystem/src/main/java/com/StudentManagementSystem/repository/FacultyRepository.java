package com.StudentManagementSystem.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.StudentManagementSystem.model.Faculty;

public interface FacultyRepository extends MongoRepository<Faculty, String> {

    Faculty findByFacultyId(String facultyId);
}