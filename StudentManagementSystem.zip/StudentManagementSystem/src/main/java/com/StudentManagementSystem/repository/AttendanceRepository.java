package com.StudentManagementSystem.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.StudentManagementSystem.model.Attendance;

public interface AttendanceRepository extends MongoRepository<Attendance, String> {

    Attendance findByAttendanceId(String attendanceId);

    List<Attendance> findByStudentId(String studentId);
}