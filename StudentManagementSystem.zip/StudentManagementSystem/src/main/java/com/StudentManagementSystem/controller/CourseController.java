package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Course;
import com.StudentManagementSystem.service.CourseService;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService service;

    @PostMapping
    public Course addCourse(@RequestBody Course course) {
        return service.addCourse(course);
    }

    @GetMapping
    public List<Course> getAllCourses() {
        return service.getAllCourses();
    }

    @GetMapping("/{courseId}")
    public Course getCourse(@PathVariable String courseId) {
        return service.getCourse(courseId);
    }

    @DeleteMapping("/{courseId}")
    public String deleteCourse(@PathVariable String courseId) {
        return service.deleteCourse(courseId);
    }
}