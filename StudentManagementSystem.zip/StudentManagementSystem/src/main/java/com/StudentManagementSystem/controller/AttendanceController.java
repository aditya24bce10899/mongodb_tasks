package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Attendance;
import com.StudentManagementSystem.service.AttendanceService;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {

    @Autowired
    private AttendanceService service;

    @PostMapping
    public Attendance addAttendance(
            @RequestBody Attendance attendance) {

        return service.addAttendance(attendance);
    }

    @GetMapping
    public List<Attendance> getAllAttendance() {

        return service.getAllAttendance();
    }

    @GetMapping("/{attendanceId}")
    public Attendance getAttendance(
            @PathVariable String attendanceId) {

        return service.getAttendance(attendanceId);
    }

    @GetMapping("/student/{studentId}")
    public List<Attendance> getStudentAttendance(
            @PathVariable String studentId) {

        return service.getStudentAttendance(studentId);
    }

    @DeleteMapping("/{attendanceId}")
    public String deleteAttendance(
            @PathVariable String attendanceId) {

        return service.deleteAttendance(attendanceId);
    }
}