package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Student;
import com.StudentManagementSystem.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService service;

    // CREATE
    @PostMapping
    public Student addStudent(@RequestBody Student student) {
        return service.addStudent(student);
    }
    @PostMapping("/bulk")
    public List<Student> addStudents(@RequestBody List<Student> students) {
        return service.addStudents(students);
    }
    // READ ALL
    @GetMapping
    public List<Student> getAllStudents() {
        return service.getAllStudents();
    }

    // READ ONE
    @GetMapping("/{studentId}")
    public Student getStudent(@PathVariable String studentId) {
        return service.getStudent(studentId);
    }

    // UPDATE
    @PutMapping("/{studentId}")
    public Student updateStudent(@PathVariable String studentId,
                                 @RequestBody Student student) {

        return service.updateStudent(studentId, student);
    }

    // DELETE
    @DeleteMapping("/{studentId}")
    public String deleteStudent(@PathVariable String studentId) {

        return service.deleteStudent(studentId);
    }

    // COUNT
    @GetMapping("/count")
    public long countStudents() {
        return service.countStudents();
    }
}