package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Enrollment;
import com.StudentManagementSystem.service.EnrollmentService;

@RestController
@RequestMapping("/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentService service;

    @PostMapping
    public Enrollment addEnrollment(
            @RequestBody Enrollment enrollment) {

        return service.addEnrollment(enrollment);
    }

    @GetMapping
    public List<Enrollment> getAllEnrollments() {
        return service.getAllEnrollments();
    }

    @GetMapping("/{enrollmentId}")
    public Enrollment getEnrollment(
            @PathVariable String enrollmentId) {

        return service.getEnrollment(enrollmentId);
    }

    @GetMapping("/student/{studentId}")
    public List<Enrollment> getStudentEnrollments(
            @PathVariable String studentId) {

        return service.getStudentEnrollments(studentId);
    }

    @GetMapping("/course/{courseId}")
    public List<Enrollment> getCourseEnrollments(
            @PathVariable String courseId) {

        return service.getCourseEnrollments(courseId);
    }

    @DeleteMapping("/{enrollmentId}")
    public String deleteEnrollment(
            @PathVariable String enrollmentId) {

        return service.deleteEnrollment(enrollmentId);
    }
}