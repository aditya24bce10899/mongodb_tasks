package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Marks;
import com.StudentManagementSystem.service.MarksService;

@RestController
@RequestMapping("/marks")
public class MarksController {

    @Autowired
    private MarksService service;

    @PostMapping
    public Marks addMarks(@RequestBody Marks marks) {
        return service.addMarks(marks);
    }

    @GetMapping
    public List<Marks> getAllMarks() {
        return service.getAllMarks();
    }

    @GetMapping("/{markId}")
    public Marks getMarks(@PathVariable String markId) {
        return service.getMarks(markId);
    }

    @GetMapping("/student/{studentId}")
    public List<Marks> getStudentMarks(
            @PathVariable String studentId) {

        return service.getStudentMarks(studentId);
    }

    @DeleteMapping("/{markId}")
    public String deleteMarks(
            @PathVariable String markId) {

        return service.deleteMarks(markId);
    }
}