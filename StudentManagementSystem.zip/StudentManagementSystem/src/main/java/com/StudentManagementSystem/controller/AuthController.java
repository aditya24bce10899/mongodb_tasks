package com.StudentManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Admin;
import com.StudentManagementSystem.repository.AdminRepository;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AdminRepository repo;

    @PostMapping("/register")
    public Admin register(@RequestBody Admin admin) {
        return repo.save(admin);
    }

    @PostMapping("/login")
    public String login(@RequestBody Admin admin) {

        Admin existing =
                repo.findByUsername(admin.getUsername());

        if(existing != null &&
           existing.getPassword().equals(admin.getPassword())) {

            return "Login Successful";
        }

        return "Invalid Username or Password";
    }
}