package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.StudentManagementSystem.model.Faculty;
import com.StudentManagementSystem.service.FacultyService;

@RestController
@RequestMapping("/faculty")
public class FacultyController {

    @Autowired
    private FacultyService service;

    @PostMapping
    public Faculty addFaculty(@RequestBody Faculty faculty) {
        return service.addFaculty(faculty);
    }

    @GetMapping
    public List<Faculty> getAllFaculty() {
        return service.getAllFaculty();
    }

    @GetMapping("/{facultyId}")
    public Faculty getFaculty(@PathVariable String facultyId) {
        return service.getFaculty(facultyId);
    }

    @DeleteMapping("/{facultyId}")
    public String deleteFaculty(@PathVariable String facultyId) {
        return service.deleteFaculty(facultyId);
    }
}