package com.StudentManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.StudentManagementSystem.model.Student;
import com.StudentManagementSystem.service.CourseService;
import com.StudentManagementSystem.service.EnrollmentService;
import com.StudentManagementSystem.service.FacultyService;
import com.StudentManagementSystem.service.MarksService;
import com.StudentManagementSystem.service.StudentService;

@RestController
public class AnalyticsController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private FacultyService facultyService;

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private MarksService marksService;

    @GetMapping("/analytics/students/count")
    public long countStudents() {
        return studentService.countStudents();
    }

    @GetMapping("/analytics/courses/count")
    public long countCourses() {
        return courseService.countCourses();
    }

    @GetMapping("/analytics/faculty/count")
    public long countFaculty() {
        return facultyService.countFaculty();
    }

    @GetMapping("/analytics/enrollments/count")
    public long countEnrollments() {
        return enrollmentService.countEnrollments();
    }

    @GetMapping("/analytics/marks/count")
    public long countMarks() {
        return marksService.countMarks();
    }

    @GetMapping("/analytics/topper")
    public Student topper() {
        return studentService.getTopper();
    }
}